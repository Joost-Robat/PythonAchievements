# Galgje

## Te raden woord

|.|.|.|.|.|
|-|-|-|-|-|
|1|2|3|4|5|

## Score
![gallow](./images/1.png)

## Beurten